/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdio.h"

uint32 entero;
uint32 voltaje;
float32 temperatura;
char dato;
char chain[50];





int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    LCD_Start();
    ADC_Start();
    AmpO_Start();
    UART_Start();
    interrup_Start();
    
    LCD_Position(0,0);
    LCD_PrintString("Lectura de temperatura");
    LCD_Position(1,4);
    LCD_PrintString("lM35");
    
    
    

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        entero = ADC_GetResult32();
        ADC_StopConvert();
        
        
        voltaje = ADC_CountsTo_mVolts(entero);//pasamos el valor a mV
        temperatura = (voltaje/10.00)-10.00; //se pasan a grados C, teniendo en cuenta que el sensor entrega 10mV por gradoC
        sprintf(chain,"%1.f",temperatura);
        
        LCD_Position(3,5);
        LCD_PrintString(chain);
        LCD_PutChar(LCD_CUSTOM_0);
        LCD_PrintString("C    ");
        
    
        
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
